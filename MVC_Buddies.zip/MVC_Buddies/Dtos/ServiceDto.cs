﻿namespace MVC_Buddies.Dtos
{
    public class ServiceDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; }
    }

}
