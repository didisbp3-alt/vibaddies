﻿namespace MVC_Buddies.Dtos
{
    public class SpeciesDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

}
